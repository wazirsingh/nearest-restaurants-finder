package com.example.flutter_search_appbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
