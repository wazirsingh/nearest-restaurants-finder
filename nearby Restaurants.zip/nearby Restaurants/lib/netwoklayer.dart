import 'dart:async';

import 'package:http/http.dart' as http;

Future<String> fetchCountry(http.Client client) async {
  final response = await client.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=47.6204,-122.3491&radius=2500&type=restaurant&keyword=:keyword&key=AIzaSyDxVclNSQGB5WHAYQiHK-VxYKJelZ_9mjk');
  // Use the compute function to run parsePhotos in a separate isolate
  return response.body;
}
