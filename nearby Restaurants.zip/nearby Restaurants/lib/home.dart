import 'dart:convert';
import 'dart:ffi';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_search_appbar/list.dart';
import 'package:flutter_search_appbar/models/RestaurantModel.dart';
import 'package:flutter_search_appbar/netwoklayer.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:latlng/latlng.dart';
import 'models/ResultModel.dart';

class MainPage extends StatefulWidget {
  const MainPage();
  @override
  _MainPageState createState() => new _MainPageState();
}

class _MainPageState extends State<MainPage> with SingleTickerProviderStateMixin
{
  static final GlobalKey<ScaffoldState> scaffoldKey =new GlobalKey<ScaffoldState>();
  FocusNode focusNode = new FocusNode();

  static List<ResultModel> allRecords=new List<ResultModel>();
  Future<List<ResultModel>> _allRecords;
  List<ResultModel> filteredRecored=new List<ResultModel>();

  TextEditingController _searchQuery;
  bool _isSearching = false;

  LatLng _center ;
  Position currentLocation;
  double strLat;
  double strLog;

  @override
  void initState()
  {
    _searchQuery = new TextEditingController();
    getUserLocation().then((value)
    {
      setState(()
      {
        _allRecords=fetchData();
        _allRecords.then((value)
        {
            setState(() {
              filteredRecored=value;
              print(value);
            });

        });
      });

    });

       super.initState();
    }

  Future<Position> locateUser() async {
    return Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

 Future<Void> getUserLocation() async
 {
    currentLocation = await locateUser();
    setState(()
    {
      _center = LatLng(currentLocation.latitude, currentLocation.longitude);
      strLat=_center.latitude;
      strLog=_center.longitude;
    });
    print(strLat);
    print(strLog);

  }


  Future<List<ResultModel>> fetchData() async
  {
  List<ResultModel> list=new List<ResultModel>();
    Map headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      "Content-type": "application/json"
    };
    try
    {
      // String _url="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=47.6204,-122.3491&radius=2500&type=restaurant&key=AIzaSyDxVclNSQGB5WHAYQiHK-VxYKJelZ_9mjk";
      String url="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+'${strLat}'+","+'${strLog}'+"&radius=50000&type=restaurant&keyword=:keyword&key=AIzaSyDxVclNSQGB5WHAYQiHK-VxYKJelZ_9mjk";
      print(url);
      final response = await http.get(url);
      if (response.statusCode == 200)
      {
        var json_response = json.decode(response.body)['results'];
        list = (json_response as List).map((i) =>ResultModel.fromJson(i)).toList();
      }
      else {
        print(response.statusCode);
      }
    }
    catch (error) {
      print(error.toString ());
    }
return list;
  }
  // List<RestaurantModel> allRestaurants;


  void _startSearch()
  {
    ModalRoute.of(context).addLocalHistoryEntry(new LocalHistoryEntry(onRemove: _stopSearching));
    setState(() {
      _isSearching = true;
    });
    print(allRecords.length);
  }


  void _stopSearching()
  {
    print(allRecords.length);
    _clearSearchQuery();
    setState(()
    {
      _isSearching = false;
      filteredRecored.addAll(allRecords);
    });
  }

  void _clearSearchQuery() {
    setState(() {
      _searchQuery.clear();
      updateSearchQuery("Search query");
    });
  }

  Widget _buildTitle(BuildContext context)
  {
    var horizontalTitleAlignment =Platform.isIOS ? CrossAxisAlignment.center : CrossAxisAlignment.start;
    return new InkWell(
      onTap: () => scaffoldKey.currentState.openDrawer(),
      child: new Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1.0),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: horizontalTitleAlignment,
          children: <Widget>[
            new Text('Seach for restaurants',
            style: new TextStyle(color: Colors.black38),),
          ],
        ),
      ),
    );
  }
  Widget _buildSearchField() {
    return new TextField(
      controller: _searchQuery,
      autofocus: true,
      decoration: const InputDecoration(
        hintText: 'Search...',
        border: InputBorder.none,
        hintStyle: const TextStyle(color: Colors.black38),
      ),
      style: const TextStyle(color: Colors.black38, fontSize: 16.0),
      onChanged: updateSearchQuery,
    );
  }

  void updateSearchQuery(String newQuery)
  {
    filteredRecored.clear();

    if (newQuery.length > 0)
    {
      Future.delayed(const Duration(milliseconds: 600), ()
      {
        setState(() {
          _allRecords=fetchData() as Future<List<ResultModel>>;
          _allRecords.then((value)
          {
            setState(() {
              allRecords=value;
            });
            });
        });
      });
      Set<ResultModel> set = Set.from(allRecords);
      set.forEach((element) => filterList(element, newQuery));
    }
    if (newQuery.isEmpty) {
      filteredRecored.addAll(allRecords);
    }

    setState(() {});
  }


  filterList(ResultModel restaurant, String searchQuery)
  {
    setState(() 
    {
      if (restaurant.name.toLowerCase().contains(searchQuery) || restaurant.name.toLowerCase().contains(searchQuery))
      {
        filteredRecored.add(restaurant);
      }
    });
    print(filteredRecored.length);
  }

  List<Widget> _buildActions()
  {
    if (_isSearching)
    {
      return <Widget>[
        new IconButton(
          icon: const Icon(Icons.clear,color: Colors.white,),
          onPressed: ()
          {
            if (_searchQuery == null || _searchQuery.text.isEmpty)
            {
              Navigator.pop(context);
              return;
            }
            _clearSearchQuery();
          },
        ),
      ];
    }

    return <Widget>[
      new IconButton(
        icon: const Icon(Icons.search,color: Colors.black38,),
        onPressed: _startSearch,
      ),
    ];
  }

  @override
  Widget build(BuildContext context)
  {
    var horizontalTitleAlignment =Platform.isIOS ? CrossAxisAlignment.center : CrossAxisAlignment.start;
    String imageURL="https://images.squarespace-cdn.com/content/v1/5497ab83e4b02e9f5e5cec35/1465367601171-DE6J8D2QQP7MVJ0QHPZR/https%3A%2F%2Fpixabay.com%2Fstatic%2Fuploads%2Fphoto%2F2015%2F09%2F14%2F11%2F43%2Frestaurant-939435_960_720.jpg?format=1000w";
    return new Scaffold(

      key: scaffoldKey,
      appBar: new AppBar(
        backgroundColor: Colors.teal,
        title: Text("Near by Restaurants "),
      ),
      body:Stack(
        children: <Widget>[
          Container(
            child:new TextField(
              controller: _searchQuery,
              autofocus: true,
              enabled: true,
              onTap: (){
                FocusScope.of(context).requestFocus(focusNode);
              },
              decoration: const InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: const BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                ),
                prefixIcon: Icon(Icons.search,color: Colors.black38,),
                hintText: 'Search for restaurants',
                hintStyle: const TextStyle(color: Colors.black38),
              ),
              style: const TextStyle(color: Colors.black38, fontSize: 18.0),
              onChanged: updateSearchQuery,
            ),
            padding: EdgeInsets.all(10),
          ),
          filteredRecored != null && filteredRecored.length > 0?
          FutureBuilder<List<ResultModel>>(
            future: _allRecords,
            builder: (context, snapshot)
            {
              if (snapshot.hasData)
              {
                return GridView.builder(
                    padding: EdgeInsets.only(top:100),
                    itemCount: filteredRecored.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        childAspectRatio: 4,
                        // childAspectRatio: (150.0 / 220.0),
                        crossAxisCount: 1),
                    itemBuilder: (context, index)
                    {
                      return
                        Container(
                          width: MediaQuery.of(context).size.width,
                          color: Colors.white70,
                          padding: EdgeInsets.all(10),
                          child:
                          Row(
                            // mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 88,
                                child: AspectRatio(
                                  aspectRatio: 1.0,
                                  child: Container(
                                    // padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: Color(0xFFF5F6F9),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child:
                                    CachedNetworkImage(
                                      imageUrl:  filteredRecored[index].icon,
                                      imageBuilder: (context, imageProvider) => Container(
                                        width: 80.0,
                                        height: 80.0,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.rectangle,
                                          borderRadius: BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: imageProvider, fit: BoxFit.cover),
                                        ),
                                      ),
                                      placeholder: (context, url) => CircularProgressIndicator(),
                                      errorWidget: (context, url, error) => Icon(Icons.error),
                                    ),

                                  ),
                                ),
                              ),
                              SizedBox(width: 10),
                              Column(
                                // mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      width: 250,
                                      child:Expanded(child: Text(
                                        filteredRecored[index].name,
                                        style: TextStyle(
                                            color: Colors.black, fontSize: 15,fontWeight: FontWeight.bold),
                                        // maxLines: 2,
                                      ))
                                  ),

                                  SizedBox(height: 5),
                                  Container(
                                      width: 250,
                                      child:Expanded(child: Text(
                                    filteredRecored[index].vicinity,
                                    style: TextStyle(
                                        color: Colors.black38, fontSize: 13),
                                    maxLines: 2,
                                  ))),
                                ],
                              ),

                              Spacer(),
                              Container(
                                // color: Colors.black38,
                                // padding: EdgeInsets.only(left:10),
                                  child:Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    textDirection: TextDirection.rtl,
                                    children: <Widget>[
                                      Container(
                                        height: 25,
                                        width:  30,
                                        // padding: EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                            color: Colors.green,
                                            borderRadius: BorderRadius.all(Radius.circular(5))
                                        ),
                                        child:
                                        Container(
                                          child:Center(child:Text(
                                              filteredRecored[index].rating.toString(),
                                              style: TextStyle(color: Colors.white,
                                              ))),
                                        ),
                                      ),

                                    ],
                                  )
                              ),

                            ],
                          ),
                        );
                    });

              }
              return Center(child: CircularProgressIndicator());
            },
          ):
          (filteredRecored==null)
              ? new Center(child: new CircularProgressIndicator())
              : new Center(
            child: new Text("No recored match!"),
          ),
        ],
      )
    );
  }

  StringBuffer getType(List<String> types)
  {
    StringBuffer strTypes=new StringBuffer();

    for(int i=0;i<types.length;i++)
      {
        strTypes.write(types[i]+", ");
      }
 return strTypes;
  }
}
