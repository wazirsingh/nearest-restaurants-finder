import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_search_appbar/models/RestaurantModel.dart';
import 'package:flutter_search_appbar/models/ResultModel.dart';
class Restaurants extends StatefulWidget
{
  Future<List<ResultModel>> allRecords;
  List<ResultModel> filterRecords;
  Restaurants(List<ResultModel> filteredRecored,Future<List<ResultModel>> allRecords)
  {
    this.allRecords=allRecords;
    this.filterRecords=filteredRecored;
  }
  @override
  RestaurantList createState() => new RestaurantList(this.filterRecords,this.allRecords);
}
class RestaurantList extends State<Restaurants>
{
  Future<List<ResultModel>> allRecords;
  List<ResultModel> filterRecords;

  RestaurantList(List<ResultModel> filteredRecored,Future<List<ResultModel>> allRecords)
  {
    this.allRecords=allRecords;
    this.filterRecords=filteredRecored;
  }
  @override
  Widget build(BuildContext context)
  {

    return  FutureBuilder<List<ResultModel>>(
        future: allRecords,
        builder: (context, snapshot)
        {
          if (snapshot.hasData)
          {
            return Stack(children: [
              Container(
                height: 200,
                child: Text('aaaaa'),
              ),
            GridView.builder(
             padding: EdgeInsets.only(top:100),
            itemCount: filterRecords.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    childAspectRatio: 4,
                    mainAxisSpacing: 2.0,
                    crossAxisCount: 1),
                itemBuilder: (context, index)
                {
                  return
                    Container(
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white70,
                      padding: EdgeInsets.all(10),
                      child:
                      Row(
                        children: [
                          SizedBox(
                            width: 88,
                            child: AspectRatio(
                              aspectRatio: 0.66,
                              child: Container(
                                // padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: Color(0xFFF5F6F9),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: CachedNetworkImage(
                                  imageUrl: '${filterRecords[index].icon}',
                                  placeholder: (context, url) => CircularProgressIndicator(),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  width: 250,
                                  child:Expanded(child: Text(
                                    filterRecords[index].name,
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18,fontWeight: FontWeight.bold),
                                    // maxLines: 2,
                                  ))
                              ),
                              SizedBox(height: 5),
                              Expanded(child: Text(
                                filterRecords[index].plusCode.compoundCode,
                                style: TextStyle(
                                    color: Colors.black38, fontSize: 16),
                                maxLines: 2,
                              )),
                            ],
                          ),

                          Spacer(),
                          Container(
                            // color: Colors.black38,
                            // padding: EdgeInsets.only(left:10),
                              child:Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                textDirection: TextDirection.rtl,
                                children: <Widget>[
                                  Container(
                                    height: 25,
                                    width:  30,
                                    // padding: EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                        color: Colors.green,
                                        borderRadius: BorderRadius.all(Radius.circular(5))
                                    ),
                                    child:
                                    Container(
                                      child:Center(child:Text(
                                          filterRecords[index].rating.toString(),
                                          style: TextStyle(color: Colors.white,
                                          ))),
                                    ),
                                  ),

                                ],
                              )
                          ),

                        ],
                      ),
                    );
                })
            ],);

          }
          return Center(child: CircularProgressIndicator());
        },
      );

  }
}



